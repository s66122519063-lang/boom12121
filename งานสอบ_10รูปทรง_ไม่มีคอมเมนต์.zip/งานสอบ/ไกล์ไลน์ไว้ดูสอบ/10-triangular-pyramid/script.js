function calculateVolume() {
    
    const base = parseFloat(document.getElementById("inBase").value);
    const triangleHeight = parseFloat(document.getElementById("inTriangleHeight").value);
    const height = parseFloat(document.getElementById("inHeight").value);
    const unit = parseFloat(document.getElementById("inUnit").value);

    const values = [base, triangleHeight, height];
    const result = document.getElementById("result");
    if (!values.every(value => Number.isFinite(value) && value > 0)) {
        result.classList.add("error");
        result.textContent = "Please enter positive values for all fields.";
        return;
    }

    const volume = (base * triangleHeight * height) / (6 * unit); 

    result.classList.remove("error");
    result.innerHTML = "Volume = " + volume.toFixed(2) + " cm<sup>3</sup>";
}

document.getElementById("volumeCalculator").addEventListener("submit", function(event) {
    event.preventDefault();
    calculateVolume();
});
