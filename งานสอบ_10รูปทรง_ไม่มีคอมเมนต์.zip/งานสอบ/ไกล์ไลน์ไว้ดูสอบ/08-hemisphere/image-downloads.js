const imageDownloads = {"asset/example.svg": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNjAiIGhlaWdodD0iMjcwIiB2aWV3Qm94PSIwIDAgMzAwIDI3MCIgcm9sZT0iaW1nIj48c3R5bGU+dGV4dHtmaWxsOiMyMjM3NDY7Zm9udC1mYW1pbHk6QXJpYWwsc2Fucy1zZXJpZn08L3N0eWxlPjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iMjcwIiBmaWxsPSIjZjdmYWZjIi8+PHBhdGggZD0iTTUzIDE1NSBBOTcgOTcgMCAwIDEgMjQ3IDE1NSIgZmlsbD0iI2UyZWVmNCIgc3Ryb2tlPSIjMjczNjQ1IiBzdHJva2Utd2lkdGg9IjIiLz48ZWxsaXBzZSBjeD0iMTUwIiBjeT0iMTU1IiByeD0iOTciIHJ5PSIyOCIgZmlsbD0iI2U4ZjNmNyIgZmlsbC1vcGFjaXR5PSIuOCIgc3Ryb2tlPSIjMjczNjQ1IiBzdHJva2Utd2lkdGg9IjIiLz48cGF0aCBkPSJNNTMgMTU1IFExNTAgMTI2IDI0NyAxNTUiIHN0cm9rZT0iIzI3MzY0NSIgc3Ryb2tlLWRhc2hhcnJheT0iNCA0IiBmaWxsPSJub25lIi8+PGxpbmUgeDE9IjE1MCIgeTE9IjE1NSIgeDI9IjI0NyIgeTI9IjE1NSIgc3Ryb2tlPSIjMjk0ZjYzIiBzdHJva2Utd2lkdGg9IjIiLz48dGV4dCB4PSIxOTgiIHk9IjE0OCIgZm9udC1zaXplPSIxNyI+cjwvdGV4dD48L3N2Zz4=", "asset/geometry.svg": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNjAiIGhlaWdodD0iMjcwIiB2aWV3Qm94PSIwIDAgMzAwIDI3MCIgcm9sZT0iaW1nIj48c3R5bGU+dGV4dHtmaWxsOiMyMjM3NDY7Zm9udC1mYW1pbHk6QXJpYWwsc2Fucy1zZXJpZn08L3N0eWxlPjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iMjcwIiBmaWxsPSJ3aGl0ZSIvPjxwYXRoIGQ9Ik01MyAxNTUgQTk3IDk3IDAgMCAxIDI0NyAxNTUiIGZpbGw9IiNlMmVlZjQiIHN0cm9rZT0iIzI3MzY0NSIgc3Ryb2tlLXdpZHRoPSIyIi8+PGVsbGlwc2UgY3g9IjE1MCIgY3k9IjE1NSIgcng9Ijk3IiByeT0iMjgiIGZpbGw9IiNlOGYzZjciIGZpbGwtb3BhY2l0eT0iLjgiIHN0cm9rZT0iIzI3MzY0NSIgc3Ryb2tlLXdpZHRoPSIyIi8+PHBhdGggZD0iTTUzIDE1NSBRMTUwIDEyNiAyNDcgMTU1IiBzdHJva2U9IiMyNzM2NDUiIHN0cm9rZS1kYXNoYXJyYXk9IjQgNCIgZmlsbD0ibm9uZSIvPjxsaW5lIHgxPSIxNTAiIHkxPSIxNTUiIHgyPSIyNDciIHkyPSIxNTUiIHN0cm9rZT0iIzI5NGY2MyIgc3Ryb2tlLXdpZHRoPSIyIi8+PHRleHQgeD0iMTk4IiB5PSIxNDgiIGZvbnQtc2l6ZT0iMTciPnI8L3RleHQ+PC9zdmc+"};
document.querySelectorAll('.file-downloads a[download]').forEach(function(link) {
    link.addEventListener('click', function(event) {
        const image = imageDownloads[link.getAttribute('href')];
        if (!image) return;
        event.preventDefault();
        const target = document.createElement('a');
        target.href = image;
        target.download = link.getAttribute('download');
        document.body.appendChild(target);
        target.click();
        target.remove();
    });
});
