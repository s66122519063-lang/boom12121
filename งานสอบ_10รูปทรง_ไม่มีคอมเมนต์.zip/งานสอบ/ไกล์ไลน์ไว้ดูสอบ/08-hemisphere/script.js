function calculateVolume() {
    
    const radius = parseFloat(document.getElementById("inRadius").value);
    const unit = parseFloat(document.getElementById("inUnit").value);

    const values = [radius];
    const result = document.getElementById("result");
    if (!values.every(value => Number.isFinite(value) && value > 0)) {
        result.classList.add("error");
        result.textContent = "Please enter positive values for all fields.";
        return;
    }

    const volume = (2 / 3) * Math.PI * Math.pow(radius, 3) / unit; 

    result.classList.remove("error");
    result.innerHTML = "Volume = " + volume.toFixed(2) + " cm<sup>3</sup>";
}

document.getElementById("volumeCalculator").addEventListener("submit", function(event) {
    event.preventDefault();
    calculateVolume();
});
