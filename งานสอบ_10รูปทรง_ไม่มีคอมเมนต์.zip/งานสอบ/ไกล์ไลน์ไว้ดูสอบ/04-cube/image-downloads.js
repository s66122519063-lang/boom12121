const imageDownloads = {"asset/example.svg": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNjAiIGhlaWdodD0iMjcwIiB2aWV3Qm94PSIwIDAgMzAwIDI3MCIgcm9sZT0iaW1nIj48c3R5bGU+dGV4dHtmaWxsOiMyMjM3NDY7Zm9udC1mYW1pbHk6QXJpYWwsc2Fucy1zZXJpZn08L3N0eWxlPjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iMjcwIiBmaWxsPSIjZjdmYWZjIi8+PHBvbHlnb24gcG9pbnRzPSI5NSw5NiAxODUsOTYgMjI2LDU3IDEzNiw1NyIgZmlsbD0iI2Q0ZTVlZCIgc3Ryb2tlPSIjMjczNjQ1IiBzdHJva2Utd2lkdGg9IjIiLz48cG9seWdvbiBwb2ludHM9IjE4NSw5NiAyMjYsNTcgMjI2LDE2OSAxODUsMjA3IiBmaWxsPSIjYWJjOWQ5IiBzdHJva2U9IiMyNzM2NDUiIHN0cm9rZS13aWR0aD0iMiIvPjxyZWN0IHg9Ijk1IiB5PSI5NiIgd2lkdGg9IjkwIiBoZWlnaHQ9IjExMSIgZmlsbD0iI2U2ZjBmNSIgc3Ryb2tlPSIjMjczNjQ1IiBzdHJva2Utd2lkdGg9IjIiLz48dGV4dCB4PSIxMzUiIHk9IjIyNCIgZm9udC1zaXplPSIxOCI+YTwvdGV4dD48dGV4dCB4PSI3OCIgeT0iMTU5IiBmb250LXNpemU9IjE3Ij5hPC90ZXh0Pjx0ZXh0IHg9IjIwMiIgeT0iOTAiIGZvbnQtc2l6ZT0iMTciPmE8L3RleHQ+PC9zdmc+", "asset/geometry.svg": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNjAiIGhlaWdodD0iMjcwIiB2aWV3Qm94PSIwIDAgMzAwIDI3MCIgcm9sZT0iaW1nIj48c3R5bGU+dGV4dHtmaWxsOiMyMjM3NDY7Zm9udC1mYW1pbHk6QXJpYWwsc2Fucy1zZXJpZn08L3N0eWxlPjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iMjcwIiBmaWxsPSJ3aGl0ZSIvPjxwb2x5Z29uIHBvaW50cz0iOTUsOTYgMTg1LDk2IDIyNiw1NyAxMzYsNTciIGZpbGw9IiNkNGU1ZWQiIHN0cm9rZT0iIzI3MzY0NSIgc3Ryb2tlLXdpZHRoPSIyIi8+PHBvbHlnb24gcG9pbnRzPSIxODUsOTYgMjI2LDU3IDIyNiwxNjkgMTg1LDIwNyIgZmlsbD0iI2FiYzlkOSIgc3Ryb2tlPSIjMjczNjQ1IiBzdHJva2Utd2lkdGg9IjIiLz48cmVjdCB4PSI5NSIgeT0iOTYiIHdpZHRoPSI5MCIgaGVpZ2h0PSIxMTEiIGZpbGw9IiNlNmYwZjUiIHN0cm9rZT0iIzI3MzY0NSIgc3Ryb2tlLXdpZHRoPSIyIi8+PHRleHQgeD0iMTM1IiB5PSIyMjQiIGZvbnQtc2l6ZT0iMTgiPmE8L3RleHQ+PHRleHQgeD0iNzgiIHk9IjE1OSIgZm9udC1zaXplPSIxNyI+YTwvdGV4dD48dGV4dCB4PSIyMDIiIHk9IjkwIiBmb250LXNpemU9IjE3Ij5hPC90ZXh0Pjwvc3ZnPg=="};
document.querySelectorAll('.file-downloads a[download]').forEach(function(link) {
    link.addEventListener('click', function(event) {
        const image = imageDownloads[link.getAttribute('href')];
        if (!image) return;
        event.preventDefault();
        const target = document.createElement('a');
        target.href = image;
        target.download = link.getAttribute('download');
        document.body.appendChild(target);
        target.click();
        target.remove();
    });
});
