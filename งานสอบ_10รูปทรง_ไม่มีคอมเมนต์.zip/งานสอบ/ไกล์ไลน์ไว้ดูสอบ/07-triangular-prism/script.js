function calculateVolume() {
    
    const base = parseFloat(document.getElementById("inBase").value);
    const triangleHeight = parseFloat(document.getElementById("inTriangleHeight").value);
    const length = parseFloat(document.getElementById("inLength").value);
    const unit = parseFloat(document.getElementById("inUnit").value);

    const values = [base, triangleHeight, length];
    const result = document.getElementById("result");
    if (!values.every(value => Number.isFinite(value) && value > 0)) {
        result.classList.add("error");
        result.textContent = "Please enter positive values for all fields.";
        return;
    }

    const volume = (base * triangleHeight * length) / (2 * unit); 

    result.classList.remove("error");
    result.innerHTML = "Volume = " + volume.toFixed(2) + " cm<sup>3</sup>";
}

document.getElementById("volumeCalculator").addEventListener("submit", function(event) {
    event.preventDefault();
    calculateVolume();
});
