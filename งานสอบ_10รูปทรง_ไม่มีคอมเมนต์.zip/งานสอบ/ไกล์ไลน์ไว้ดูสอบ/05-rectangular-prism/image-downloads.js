const imageDownloads = {"asset/example.svg": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNjAiIGhlaWdodD0iMjcwIiB2aWV3Qm94PSIwIDAgMzAwIDI3MCIgcm9sZT0iaW1nIj48c3R5bGU+dGV4dHtmaWxsOiMyMjM3NDY7Zm9udC1mYW1pbHk6QXJpYWwsc2Fucy1zZXJpZn08L3N0eWxlPjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iMjcwIiBmaWxsPSIjZjdmYWZjIi8+PHBvbHlnb24gcG9pbnRzPSI2OCwxMDMgMjAwLDEwMyAyNTIsNTkgMTIwLDU5IiBmaWxsPSIjZDRlNWVkIiBzdHJva2U9IiMyNzM2NDUiIHN0cm9rZS13aWR0aD0iMiIvPjxwb2x5Z29uIHBvaW50cz0iMjAwLDEwMyAyNTIsNTkgMjUyLDE3MiAyMDAsMjE1IiBmaWxsPSIjYWZjYmQ5IiBzdHJva2U9IiMyNzM2NDUiIHN0cm9rZS13aWR0aD0iMiIvPjxyZWN0IHg9IjY4IiB5PSIxMDMiIHdpZHRoPSIxMzIiIGhlaWdodD0iMTEyIiBmaWxsPSIjZThmMmY2IiBzdHJva2U9IiMyNzM2NDUiIHN0cm9rZS13aWR0aD0iMiIvPjx0ZXh0IHg9IjEyNiIgeT0iMjM0IiBmb250LXNpemU9IjE3Ij5sPC90ZXh0Pjx0ZXh0IHg9IjQ4IiB5PSIxNjYiIGZvbnQtc2l6ZT0iMTciPmg8L3RleHQ+PHRleHQgeD0iMjMwIiB5PSIyMTMiIGZvbnQtc2l6ZT0iMTciPnc8L3RleHQ+PC9zdmc+", "asset/geometry.svg": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNjAiIGhlaWdodD0iMjcwIiB2aWV3Qm94PSIwIDAgMzAwIDI3MCIgcm9sZT0iaW1nIj48c3R5bGU+dGV4dHtmaWxsOiMyMjM3NDY7Zm9udC1mYW1pbHk6QXJpYWwsc2Fucy1zZXJpZn08L3N0eWxlPjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iMjcwIiBmaWxsPSJ3aGl0ZSIvPjxwb2x5Z29uIHBvaW50cz0iNjgsMTAzIDIwMCwxMDMgMjUyLDU5IDEyMCw1OSIgZmlsbD0iI2Q0ZTVlZCIgc3Ryb2tlPSIjMjczNjQ1IiBzdHJva2Utd2lkdGg9IjIiLz48cG9seWdvbiBwb2ludHM9IjIwMCwxMDMgMjUyLDU5IDI1MiwxNzIgMjAwLDIxNSIgZmlsbD0iI2FmY2JkOSIgc3Ryb2tlPSIjMjczNjQ1IiBzdHJva2Utd2lkdGg9IjIiLz48cmVjdCB4PSI2OCIgeT0iMTAzIiB3aWR0aD0iMTMyIiBoZWlnaHQ9IjExMiIgZmlsbD0iI2U4ZjJmNiIgc3Ryb2tlPSIjMjczNjQ1IiBzdHJva2Utd2lkdGg9IjIiLz48dGV4dCB4PSIxMjYiIHk9IjIzNCIgZm9udC1zaXplPSIxNyI+bDwvdGV4dD48dGV4dCB4PSI0OCIgeT0iMTY2IiBmb250LXNpemU9IjE3Ij5oPC90ZXh0Pjx0ZXh0IHg9IjIzMCIgeT0iMjEzIiBmb250LXNpemU9IjE3Ij53PC90ZXh0Pjwvc3ZnPg=="};
document.querySelectorAll('.file-downloads a[download]').forEach(function(link) {
    link.addEventListener('click', function(event) {
        const image = imageDownloads[link.getAttribute('href')];
        if (!image) return;
        event.preventDefault();
        const target = document.createElement('a');
        target.href = image;
        target.download = link.getAttribute('download');
        document.body.appendChild(target);
        target.click();
        target.remove();
    });
});
