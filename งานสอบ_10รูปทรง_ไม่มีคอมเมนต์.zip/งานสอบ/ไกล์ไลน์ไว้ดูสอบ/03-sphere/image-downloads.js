const imageDownloads = {"asset/example.svg": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNjAiIGhlaWdodD0iMjcwIiB2aWV3Qm94PSIwIDAgMzAwIDI3MCIgcm9sZT0iaW1nIj48c3R5bGU+dGV4dHtmaWxsOiMyMjM3NDY7Zm9udC1mYW1pbHk6QXJpYWwsc2Fucy1zZXJpZn08L3N0eWxlPjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iMjcwIiBmaWxsPSIjZjdmYWZjIi8+PGNpcmNsZSBjeD0iMTUwIiBjeT0iMTMyIiByPSI5NCIgZmlsbD0iI2U2ZjBmNSIgZmlsbC1vcGFjaXR5PSIuNSIgc3Ryb2tlPSIjMjczNjQ1IiBzdHJva2Utd2lkdGg9IjIiLz48cGF0aCBkPSJNNTYgMTMyIEM4NSA5MCAyMTUgOTAgMjQ0IDEzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjczNjQ1IiBzdHJva2UtZGFzaGFycmF5PSI1IDUiLz48cGF0aCBkPSJNNTYgMTMyIEM4NSAxNzQgMjE1IDE3NCAyNDQgMTMyIiBmaWxsPSJub25lIiBzdHJva2U9IiMyNzM2NDUiLz48Y2lyY2xlIGN4PSIxNTAiIGN5PSIxMzIiIHI9IjMuNSIgZmlsbD0iIzI5NGY2MyIvPjxsaW5lIHgxPSIxNTAiIHkxPSIxMzIiIHgyPSIyNDQiIHkyPSIxMzIiIHN0cm9rZT0iIzI5NGY2MyIgc3Ryb2tlLXdpZHRoPSIyIi8+PHRleHQgeD0iMTk4IiB5PSIxMjUiIGZvbnQtc2l6ZT0iMTciPnI8L3RleHQ+PC9zdmc+", "asset/geometry.svg": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNjAiIGhlaWdodD0iMjcwIiB2aWV3Qm94PSIwIDAgMzAwIDI3MCIgcm9sZT0iaW1nIj48c3R5bGU+dGV4dHtmaWxsOiMyMjM3NDY7Zm9udC1mYW1pbHk6QXJpYWwsc2Fucy1zZXJpZn08L3N0eWxlPjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iMjcwIiBmaWxsPSJ3aGl0ZSIvPjxjaXJjbGUgY3g9IjE1MCIgY3k9IjEzMiIgcj0iOTQiIGZpbGw9IiNlNmYwZjUiIGZpbGwtb3BhY2l0eT0iLjUiIHN0cm9rZT0iIzI3MzY0NSIgc3Ryb2tlLXdpZHRoPSIyIi8+PHBhdGggZD0iTTU2IDEzMiBDODUgOTAgMjE1IDkwIDI0NCAxMzIiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzI3MzY0NSIgc3Ryb2tlLWRhc2hhcnJheT0iNSA1Ii8+PHBhdGggZD0iTTU2IDEzMiBDODUgMTc0IDIxNSAxNzQgMjQ0IDEzMiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMjczNjQ1Ii8+PGNpcmNsZSBjeD0iMTUwIiBjeT0iMTMyIiByPSIzLjUiIGZpbGw9IiMyOTRmNjMiLz48bGluZSB4MT0iMTUwIiB5MT0iMTMyIiB4Mj0iMjQ0IiB5Mj0iMTMyIiBzdHJva2U9IiMyOTRmNjMiIHN0cm9rZS13aWR0aD0iMiIvPjx0ZXh0IHg9IjE5OCIgeT0iMTI1IiBmb250LXNpemU9IjE3Ij5yPC90ZXh0Pjwvc3ZnPg=="};
document.querySelectorAll('.file-downloads a[download]').forEach(function(link) {
    link.addEventListener('click', function(event) {
        const image = imageDownloads[link.getAttribute('href')];
        if (!image) return;
        event.preventDefault();
        const target = document.createElement('a');
        target.href = image;
        target.download = link.getAttribute('download');
        document.body.appendChild(target);
        target.click();
        target.remove();
    });
});
