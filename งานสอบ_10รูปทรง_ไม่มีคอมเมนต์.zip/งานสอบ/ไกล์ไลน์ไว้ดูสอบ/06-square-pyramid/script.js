function calculateVolume() {
    
    const side = parseFloat(document.getElementById("inSide").value);
    const height = parseFloat(document.getElementById("inHeight").value);
    const unit = parseFloat(document.getElementById("inUnit").value);

    const values = [side, height];
    const result = document.getElementById("result");
    if (!values.every(value => Number.isFinite(value) && value > 0)) {
        result.classList.add("error");
        result.textContent = "Please enter positive values for all fields.";
        return;
    }

    const volume = Math.pow(side, 2) * height / (3 * unit); 

    result.classList.remove("error");
    result.innerHTML = "Volume = " + volume.toFixed(2) + " cm<sup>3</sup>";
}

document.getElementById("volumeCalculator").addEventListener("submit", function(event) {
    event.preventDefault();
    calculateVolume();
});
