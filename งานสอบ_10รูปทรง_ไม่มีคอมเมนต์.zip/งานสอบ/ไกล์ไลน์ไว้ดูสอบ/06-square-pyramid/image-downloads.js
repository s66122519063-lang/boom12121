const imageDownloads = {"asset/example.svg": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNjAiIGhlaWdodD0iMjcwIiB2aWV3Qm94PSIwIDAgMzAwIDI3MCIgcm9sZT0iaW1nIj48c3R5bGU+dGV4dHtmaWxsOiMyMjM3NDY7Zm9udC1mYW1pbHk6QXJpYWwsc2Fucy1zZXJpZn08L3N0eWxlPjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iMjcwIiBmaWxsPSIjZjdmYWZjIi8+PHBvbHlnb24gcG9pbnRzPSI2MCwxOTQgMTc1LDIzMCAyNDksMTg5IDEzNSwxNTMiIGZpbGw9IiNkOGU5ZjAiIHN0cm9rZT0iIzI3MzY0NSIgc3Ryb2tlLXdpZHRoPSIyIi8+PHBvbHlnb24gcG9pbnRzPSIxNTQsMzcgNjAsMTk0IDE3NSwyMzAiIGZpbGw9IiNlOGYyZjYiIHN0cm9rZT0iIzI3MzY0NSIgc3Ryb2tlLXdpZHRoPSIyIi8+PHBvbHlnb24gcG9pbnRzPSIxNTQsMzcgMTc1LDIzMCAyNDksMTg5IiBmaWxsPSIjYjdkM2RmIiBzdHJva2U9IiMyNzM2NDUiIHN0cm9rZS13aWR0aD0iMiIvPjxwYXRoIGQ9Ik0xNTQgMzcgTDE1NCAxODYiIHN0cm9rZT0iIzI5NGY2MyIgc3Ryb2tlLXdpZHRoPSIxLjgiIHN0cm9rZS1kYXNoYXJyYXk9IjUgNCIvPjx0ZXh0IHg9IjE1OCIgeT0iMTIxIiBmb250LXNpemU9IjE4Ij5oPC90ZXh0Pjx0ZXh0IHg9IjEwOCIgeT0iMjI3IiBmb250LXNpemU9IjE3Ij5hPC90ZXh0Pjwvc3ZnPg==", "asset/geometry.svg": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNjAiIGhlaWdodD0iMjcwIiB2aWV3Qm94PSIwIDAgMzAwIDI3MCIgcm9sZT0iaW1nIj48c3R5bGU+dGV4dHtmaWxsOiMyMjM3NDY7Zm9udC1mYW1pbHk6QXJpYWwsc2Fucy1zZXJpZn08L3N0eWxlPjxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iMjcwIiBmaWxsPSJ3aGl0ZSIvPjxwb2x5Z29uIHBvaW50cz0iNjAsMTk0IDE3NSwyMzAgMjQ5LDE4OSAxMzUsMTUzIiBmaWxsPSIjZDhlOWYwIiBzdHJva2U9IiMyNzM2NDUiIHN0cm9rZS13aWR0aD0iMiIvPjxwb2x5Z29uIHBvaW50cz0iMTU0LDM3IDYwLDE5NCAxNzUsMjMwIiBmaWxsPSIjZThmMmY2IiBzdHJva2U9IiMyNzM2NDUiIHN0cm9rZS13aWR0aD0iMiIvPjxwb2x5Z29uIHBvaW50cz0iMTU0LDM3IDE3NSwyMzAgMjQ5LDE4OSIgZmlsbD0iI2I3ZDNkZiIgc3Ryb2tlPSIjMjczNjQ1IiBzdHJva2Utd2lkdGg9IjIiLz48cGF0aCBkPSJNMTU0IDM3IEwxNTQgMTg2IiBzdHJva2U9IiMyOTRmNjMiIHN0cm9rZS13aWR0aD0iMS44IiBzdHJva2UtZGFzaGFycmF5PSI1IDQiLz48dGV4dCB4PSIxNTgiIHk9IjEyMSIgZm9udC1zaXplPSIxOCI+aDwvdGV4dD48dGV4dCB4PSIxMDgiIHk9IjIyNyIgZm9udC1zaXplPSIxNyI+YTwvdGV4dD48L3N2Zz4="};
document.querySelectorAll('.file-downloads a[download]').forEach(function(link) {
    link.addEventListener('click', function(event) {
        const image = imageDownloads[link.getAttribute('href')];
        if (!image) return;
        event.preventDefault();
        const target = document.createElement('a');
        target.href = image;
        target.download = link.getAttribute('download');
        document.body.appendChild(target);
        target.click();
        target.remove();
    });
});
